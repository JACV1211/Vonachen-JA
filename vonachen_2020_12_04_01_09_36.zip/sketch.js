function setup() {
  createCanvas(400, 400);

}
let x = 10;

function draw() {
  background(' lightblue');

  let array = []
  print(array.length = 20);

  noStroke() //ground
  colorMode(RGB)
  fill(160, 82, 45)
  rect(0, 300, 400, 100)
  fill(139, 69, 19)
  rect(0, 300, 400, 50)
  fill('green')
  rect(0, 300, 400, 20)
  fill(218, 165, 32)
  ellipse(320, 80, 90, 90)
  
    fill('blue')
    ellipse(mouseX,100,100,100)
  
  fill(200)
  stroke(1)
ellipse(mouseX,120,200,60)  

  fill(255,255,0,62)
  stroke(1)


 

  for (let i = 1; i < 150; i++) {
    array[i++]
    print(array = i++);
    ellipse(mouseX, i+150, i+10, 10)
  }
}