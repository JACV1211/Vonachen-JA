let img;
let imgPotato;
let imgPotate;
let c;

function preload(){
  imgPotato = loadImage('Pix/potato.png');
  imgPotate = loadImage('Pix/potate.png');
  imgPotato.loadPixels();
  imgPotate.loadPixels();

}

function setup() {
  createCanvas(600, 600);
}

function draw() {
  background(220);
  textFont('Georgia');
  text('War of Potatos',260, 20, 170, 100);
  
  image(imgPotato, 50, mouseY, 70, 50)
      image(imgPotato, 300, mouseY-100, 70, 50)
  image(imgPotate, 300, mouseX-100)
}